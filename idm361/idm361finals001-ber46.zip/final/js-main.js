// jwt custom code
//
function pageSetUp() {
}

function jmp2LocalPage(whichPage) {
  location.href = whichPage;
}