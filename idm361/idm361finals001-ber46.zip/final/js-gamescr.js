document.getElementById("gamescreen").style.height = window.innerHeight - document.getElementById("logo-tiny").offsetHeight - 18 + "px";
window.onresize = function(){ 
    document.getElementById("gamescreen").style.height = window.innerHeight - document.getElementById("logo-tiny").offsetHeight - 18 + "px";
 }